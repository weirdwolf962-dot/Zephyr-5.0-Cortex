import React, { useState, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";
import { Message, Role } from './types';

// Use marked from CDN
declare var marked: any;

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const LoadingScreen = () => (
  <div className="bg-white dark:bg-black h-screen flex items-center justify-center font-sans">
    <div className="loading-container">
      <div className="logo-text">Zephyr</div>
      <div className="credit-text">
        <span className="by-text">by</span> <span className="company-text">Quantum coders</span>
      </div>
    </div>
  </div>
);

const HistorySidebar = ({ isOpen, onClose, history, onLoadChat, onDeleteChat, onNewChat }: {
    isOpen: boolean;
    onClose: () => void;
    history: Message[][];
    onLoadChat: (index: number) => void;
    onDeleteChat: (index: number) => void;
    onNewChat: () => void;
}) => {
  return (
    <>
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-72 bg-gray-900 text-white transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        aria-modal="true"
        role="dialog"
      >
        <div className="flex flex-col h-full">
          <div className="p-4 flex justify-between items-center border-b border-gray-700">
            <h2 className="text-lg font-semibold">Chat History</h2>
            <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700" aria-label="Close history">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          </div>
          <div className="p-4 border-b border-gray-700">
             <button onClick={onNewChat} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                New Chat
             </button>
          </div>
          <nav className="flex-1 overflow-y-auto">
            <ul className="p-2 space-y-1">
              {history.map((chat, index) => (
                <li key={index}>
                  <a href="#" onClick={(e) => { e.preventDefault(); onLoadChat(index); }} className="flex items-center justify-between p-2 rounded-md hover:bg-gray-700 group">
                    <span className="truncate flex-1 pr-2 text-sm">
                      {chat.find(m => m.role === Role.USER)?.text || (chat.find(m => m.role === Role.USER)?.image ? "Image" : "Chat")}
                    </span>
                    <button 
                      onClick={(e) => { e.stopPropagation(); onDeleteChat(index); }} 
                      className="p-1 rounded-full text-gray-500 hover:text-white hover:bg-gray-600 opacity-0 group-hover:opacity-100 transition-opacity"
                      aria-label="Delete chat"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    </button>
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
      {isOpen && <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={onClose}></div>}
    </>
  );
};

// Helper function to process images
// Converts various image formats (AVIF, HEIC, BMP, etc.) to standard JPEG for API compatibility
const processImage = (file: File): Promise<{ data: string; mimeType: string; url: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        
        // Resize logic to keep tokens reasonable while maintaining quality
        let width = img.width;
        let height = img.height;
        const maxDim = 1536; // 1536px is sufficient for most LLM vision tasks
        
        if (width > maxDim || height > maxDim) {
           const ratio = Math.min(maxDim / width, maxDim / height);
           width *= ratio;
           height *= ratio;
        }

        canvas.width = width;
        canvas.height = height;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error("Canvas context unavailable"));
          return;
        }
        
        // Draw white background for transparency
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        
        ctx.drawImage(img, 0, 0, width, height);
        
        // Convert to JPEG
        const mimeType = 'image/jpeg';
        const quality = 0.8;
        const dataUrl = canvas.toDataURL(mimeType, quality);
        const base64Data = dataUrl.split(',')[1];
        
        resolve({
          url: dataUrl,
          data: base64Data,
          mimeType: mimeType
        });
      };
      img.onerror = (err) => {
         console.error("Image load error", err);
         reject(new Error("Failed to load image"));
      };
      
      if (typeof e.target?.result === 'string') {
          img.src = e.target.result;
      } else {
          reject(new Error("File read failed"));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};


// The main App component
const App = () => {
  const [showLoadingScreen, setShowLoadingScreen] = useState(true);
  const initialMessage: Message[] = [
    {
      role: Role.MODEL,
      text: "Hello! I'm Zephyr, your AI assistant. How can I help you today?",
    }
  ];
  const [messages, setMessages] = useState<Message[]>(initialMessage);
  const [input, setInput] = useState('');
  const [attachment, setAttachment] = useState<{ url: string; data: string; mimeType: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [chatHistory, setChatHistory] = useState<Message[][]>([]);
  const [theme, setTheme] = useState(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const storedTheme = window.localStorage.getItem('zephyr-theme');
      if (storedTheme) return storedTheme;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light';
  });

  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Theme effect
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      localStorage.setItem('zephyr-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('zephyr-theme', 'light');
    }
  }, [theme]);

  // Loading Screen Effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLoadingScreen(false);
    }, 3000); // Show loading screen for 3 seconds

    return () => clearTimeout(timer);
  }, []);

  // History Persistence Effects
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem('zephyrChatHistory');
      if (savedHistory) {
        setChatHistory(JSON.parse(savedHistory));
      }
    } catch (error) {
      console.error("Failed to load chat history from localStorage", error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('zephyrChatHistory', JSON.stringify(chatHistory));
    } catch (error) {
      console.error("Failed to save chat history to localStorage", error);
    }
  }, [chatHistory]);

  // Speech Recognition Effect
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsRecording(true);
      recognition.onresult = (event: any) => setInput(event.results[0][0].transcript);
      recognition.onend = () => setIsRecording(false);
      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
      };
      recognitionRef.current = recognition;
    } else {
      console.warn('Speech Recognition not available');
    }
  }, []);

  // Auto-scroll Effect
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(() => {
    if (!showLoadingScreen) {
      scrollToBottom();
    }
  }, [messages, showLoadingScreen, attachment]);

  const archiveCurrentChat = () => {
    if (messages.length > 1) { // Only save if there's more than the initial greeting
      setChatHistory(prev => [messages, ...prev]);
    }
  };

  const startNewChat = () => {
    archiveCurrentChat();
    setMessages(initialMessage);
    setAttachment(null);
    setInput('');
    setIsHistoryOpen(false);
  };

  const loadChat = (index: number) => {
    archiveCurrentChat();
    const chatToLoad = chatHistory[index];
    setMessages(chatToLoad);
    setChatHistory(prev => prev.filter((_, i) => i !== index));
    setIsHistoryOpen(false);
  };

  const deleteChat = (index: number) => {
    setChatHistory(prev => prev.filter((_, i) => i !== index));
  };


  const sendMessage = async (messageText: string, imageAttachment?: { data: string; mimeType: string; url: string }) => {
    if ((!messageText.trim() && !imageAttachment) || loading) return;

    const userMessage: Message = { 
        role: Role.USER, 
        text: messageText.trim(),
        image: imageAttachment?.url 
    };

    const isFirstMessage = messages.length === 1 && messages[0].role === Role.MODEL && messages[0].text.startsWith("Hello");
    const previousMessages = isFirstMessage ? [] : messages;
    const newMessages = [...previousMessages, userMessage];
    
    setMessages(newMessages);
    setInput('');
    setAttachment(null);
    setLoading(true);

    const lowerCaseInput = messageText.trim().toLowerCase();
    
    // Simple local checks - skip if image is attached to let model handle it
    if (!imageAttachment) {
        if (/\b(time|date)\b/.test(lowerCaseInput)) {
            const responseText = `The current date and time is: ${new Date().toLocaleString()}`;
            setMessages([...newMessages, { role: Role.MODEL, text: responseText }]);
            setLoading(false);
            return;
        }
        if (/\b(creator|created|made)\b/.test(lowerCaseInput) && !lowerCaseInput.includes("quantum coders")) {
            const responseText = "I was created by Mohammad Rayyan Ali.";
            setMessages([...newMessages, { role: Role.MODEL, text: responseText }]);
            setLoading(false);
            return;
        }
        if (/\b(quantum coders)\b/.test(lowerCaseInput)) {
            const responseText = "Quantum Coders is a group for a science exhibition. They created me as their project. The members are:\n1. Rayyan\n2. Amit\n3. Yatin";
            setMessages([...newMessages, { role: Role.MODEL, text: responseText }]);
            setLoading(false);
            return;
        }
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const historyForAPI = previousMessages.map(msg => {
            const parts: any[] = [{ text: msg.text }];
            // Re-construct image part if available in history
            if (msg.image) {
                const base64Data = msg.image.split(',')[1];
                const mimeType = msg.image.split(';')[0].split(':')[1];
                if (base64Data && mimeType) {
                    parts.push({
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType
                        }
                    });
                }
            }
            return {
                role: msg.role,
                parts: parts
            };
        });

        const currentParts: any[] = [];
        if (messageText.trim()) {
            currentParts.push({ text: messageText.trim() });
        }
        if (imageAttachment) {
            currentParts.push({
                inlineData: {
                    mimeType: imageAttachment.mimeType,
                    data: imageAttachment.data
                }
            });
        }

        const contents = [...historyForAPI, { role: Role.USER, parts: currentParts }];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                systemInstruction: "You are Zephyr, a helpful AI chatbot created by Mohammad Rayyan Ali. You can provide the current date and time. Use the provided tools to answer questions about current events and news. Your responses should be formatted in Markdown.",
                tools: [{ googleSearch: {} }],
            },
        });
        
        const responseText = response.text;
        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
        const sources = groundingChunks
            .map(chunk => chunk.web)
            .filter((web): web is { uri: string; title: string; } => !!(web?.uri && web.title));
        
        const modelMessage: Message = { role: Role.MODEL, text: responseText, sources: sources.length > 0 ? sources : undefined };
        setMessages([...newMessages, modelMessage]);

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        const errorMessage: Message = { role: Role.MODEL, text: "Sorry, I'm having trouble connecting. Please try again later." };
        setMessages([...newMessages, errorMessage]);
    } finally {
        setLoading(false);
    }
  };

  const handleMicClick = () => {
    if (loading || !recognitionRef.current) return;

    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      setInput('');
      recognitionRef.current.start();
    }
  };
  
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        try {
            // We set a temporary loading state purely for UI feedback if processing takes a moment
            // though usually it's instant.
            const processedImage = await processImage(file);
            setAttachment(processedImage);
        } catch (error) {
            console.error("Error processing image:", error);
            alert("Failed to process image. Please try a standard image format (PNG, JPEG).");
        }
    }
    // Reset input so the same file can be selected again
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input, attachment || undefined);
  };
  
  const renderText = (text: string) => {
    const rawHtml = marked.parse(text);
    return { __html: rawHtml };
  };
  
  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  };

  const exampleQuestions = [
    "What's the latest news?",
    "What is Array?",
    "Suggest me a recipe for dinner",
    "Who are Quantum coders?",
  ];

  if (showLoadingScreen) {
    return <LoadingScreen />;
  }

  return (
    <div className="bg-white dark:bg-gray-900 text-black dark:text-white h-screen flex flex-col font-sans">
      <HistorySidebar
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={chatHistory}
        onLoadChat={loadChat}
        onDeleteChat={deleteChat}
        onNewChat={startNewChat}
      />
      <header className="p-4 border-b border-gray-200 dark:border-gray-800 shrink-0">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Zephyr</h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">by Quantum coders</p>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? (
                 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>
              )}
            </button>
            <button 
              onClick={() => setIsHistoryOpen(true)} 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              aria-label="Open chat history"
            >
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 flex flex-col bg-gray-100 dark:bg-black">
        <div className="max-w-4xl mx-auto w-full space-y-6 flex-1">
           {messages.length === 1 && messages[0].role === Role.MODEL && messages[0].text.startsWith("Hello") ? (
             <div className="flex flex-col items-center justify-center h-full text-center">
                <h1 className="text-6xl font-bold text-black dark:text-white mb-6">Zephyr</h1>
                <div className="flex flex-wrap justify-center gap-3 w-full max-w-lg">
                    {exampleQuestions.map((q, i) => (
                        <button 
                          key={i} 
                          onClick={() => sendMessage(q)} 
                          className="px-5 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
                          disabled={loading}
                        >
                            {q}
                        </button>
                    ))}
                </div>
             </div>
           ) : (
            messages.map((msg, index) => (
              <div key={index} className={`flex items-end gap-2 ${msg.role === Role.USER ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xl p-3 rounded-2xl ${msg.role === Role.USER ? 'bg-black dark:bg-blue-600 text-white' : 'bg-white dark:bg-gray-800 text-black dark:text-gray-200'}`}>
                  {msg.image && (
                     <div className="mb-2">
                        <img src={msg.image} alt="User upload" className="max-w-full h-auto rounded-lg border border-gray-300 dark:border-gray-700" />
                     </div>
                  )}
                  {msg.text && (
                    <div className={`prose prose-sm max-w-none dark:prose-invert ${msg.role === Role.USER ? 'prose-invert' : ''}`} dangerouslySetInnerHTML={renderText(msg.text)} />
                  )}
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-gray-300 dark:border-gray-600">
                      <h4 className="text-xs font-semibold mb-1 text-gray-700 dark:text-gray-400">Sources:</h4>
                      <ul className="list-disc list-inside text-xs space-y-1">
                        {msg.sources.map((source, i) => (
                          <li key={i}>
                            <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">
                              {source.title}
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            ))
           )}
          {loading && (
            <div className="flex items-end gap-2 justify-start">
               <div className="max-w-xl p-3 rounded-2xl bg-white dark:bg-gray-800 text-black dark:text-gray-200">
                <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                    <div className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                </div>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      <footer className="p-4 border-t border-gray-200 dark:border-gray-800 shrink-0 bg-white dark:bg-gray-900">
        <div className="max-w-4xl mx-auto">
          {attachment && (
            <div className="mb-3 flex items-start">
                <div className="relative group">
                    <img src={attachment.url} alt="Attachment preview" className="h-16 w-16 object-cover rounded-lg border border-gray-200 dark:border-gray-700" />
                    <button 
                        onClick={() => setAttachment(null)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-100 shadow-sm hover:bg-red-600 transition-colors"
                        aria-label="Remove attachment"
                    >
                         <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                    </button>
                </div>
            </div>
          )}
          <form onSubmit={handleSend} className="flex items-center gap-3">
             <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleFileSelect}
             />
             <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white transition-colors"
                aria-label="Attach image"
                disabled={loading}
             >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>
             </button>
            <div className="relative flex-1">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isRecording ? "Listening..." : "Type your message..."}
                className="w-full p-3 pr-12 border border-gray-300 dark:border-gray-700 rounded-full focus:outline-none focus:ring-2 focus:ring-black dark:focus:ring-white transition-shadow bg-transparent dark:text-white"
                disabled={loading || isRecording}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend(e as any);
                  }
                }}
              />
              <button
                type="button"
                onClick={handleMicClick}
                disabled={loading}
                className={`absolute inset-y-0 right-0 flex items-center pr-3 rounded-full text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white transition-colors ${isRecording ? 'text-red-500 dark:text-red-400' : ''}`}
                aria-label={isRecording ? 'Stop recording' : 'Start recording'}
              >
                {isRecording ? (
                  <svg className="w-6 h-6 animate-pulse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z"></path><path d="M12 7c-2.757 0-5 2.243-5 5s2.243 5 5 5 5-2.243 5-5-2.243-5-5-5z"></path></svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                    <line x1="12" y1="19" x2="12" y2="22"></line>
                  </svg>
                )}
              </button>
            </div>
            <button
              type="submit"
              disabled={(!input.trim() && !attachment) || loading}
              className="p-3 bg-black dark:bg-white text-white dark:text-black rounded-full disabled:bg-gray-400 dark:disabled:bg-gray-600 hover:bg-gray-800 dark:hover:bg-gray-300 transition-colors flex-shrink-0"
              aria-label="Send message"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        </div>
      </footer>
    </div>
  );
};

// Mount the app
const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);